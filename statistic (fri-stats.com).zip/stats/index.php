<?php

if (file_exists("utf8.dat")) include("fri_utf8.php"); else include("fri.php");

?>
