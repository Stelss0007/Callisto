<?php /* Smarty version 2.6.20, created on 2013-10-21 17:09:22
         compiled from D:/www/callisto/www/modules/users/themes/default/users_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'D:/www/callisto/www/modules/users/themes/default/users_list.tpl', 33, false),array('modifier', 'date_format', 'D:/www/callisto/www/modules/users/themes/default/users_list.tpl', 56, false),)), $this); ?>
<h2>����� �������������</h2>
<table border='1' width='100%' cellspacing=0 cellpadding=2>
  <thead style="">
    <tr>
      <th>
        ID
      </th>
      <th>
        �����
      </th>
      <th>
        ���(�.�.�)
      </th>
      <th>
        E-mail
      </th>
      <th>
        ������
      </th>
      <th>
        ���� �����������
      </th>
      <th>
        ��������� ���� � ��������
      </th>
      <th>
        ��������
      </th>
     </tr>
  </thead>
  <tbody>
   <?php $_from = $this->_tpl_vars['users_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['user']):
?>
    <?php echo smarty_function_cycle(array('name' => 'users','values' => "even,odd",'assign' => 'class','print' => false), $this);?>

    <tr class='<?php echo $this->_tpl_vars['class']; ?>
'>
      <td>
        <?php echo $this->_tpl_vars['user']['id']; ?>

      </td>
      
      <td>
        <?php echo $this->_tpl_vars['user']['login']; ?>

      </td>
      
      <td>
        <?php echo $this->_tpl_vars['user']['displayname']; ?>

      </td>
     
      <td>
        <?php echo $this->_tpl_vars['user']['mail']; ?>

      </td>
     
      <td>
        <?php echo $this->_tpl_vars['groups_list'][$this->_tpl_vars['user']['gid']]; ?>

      </td>
      
      <td>
        <?php echo ((is_array($_tmp=$this->_tpl_vars['user']['addtime'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d.%m.%Y') : smarty_modifier_date_format($_tmp, '%d.%m.%Y')); ?>

      </td>
      
      <td>
        <?php echo ((is_array($_tmp=$this->_tpl_vars['user']['last_visit'])) ? $this->_run_mod_handler('date_format', true, $_tmp, '%d.%m.%Y %H:%M') : smarty_modifier_date_format($_tmp, '%d.%m.%Y %H:%M')); ?>

      </td>
      
      <td>
        <?php if ($this->_tpl_vars['user']['active']): ?>
          <a href='/users/activation/<?php echo $this->_tpl_vars['user']['id']; ?>
' onclick="return confirm('��������������?')">Disabled</a>&nbsp;|&nbsp;
        <?php else: ?>
          <a href='/users/activation/<?php echo $this->_tpl_vars['user']['id']; ?>
' onclick="return confirm('������������?')">Enabled</a>&nbsp;|&nbsp;
        <?php endif; ?>
        <a href='/users/manage/<?php echo $this->_tpl_vars['user']['id']; ?>
'>Edit</a>&nbsp;|&nbsp;
        <a href='/users/delete/<?php echo $this->_tpl_vars['user']['id']; ?>
' onclick="return confirm('������� �������?')">Delete</a>
      </td>
    </tr>
   <?php endforeach; endif; unset($_from); ?>
  </tbody>
</table>
<div style="text-align: center;">
  [ <a href='/users/manage'>��������</a> ]
</div>