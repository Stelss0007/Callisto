<?php /* Smarty version 2.6.20, created on 2013-10-22 10:19:58
         compiled from D:/www/callisto/www/modules/permissions/views/default/manage.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', 'D:/www/callisto/www/modules/permissions/views/default/manage.tpl', 19, false),)), $this); ?>
<form action="" method="post">
  <input type="hidden" name='id' value="<?php echo $this->_tpl_vars['id']; ?>
">
  <table class="outer" cellSpacing="1" cellPadding="4" width="100%">
    <colgroup>
      <col width="25%">
      <col width="75%">
    </colgroup>
    <thead>
      <th colspan="2">
        �������������� ���� �������
      </th>
    </thead>
    <tbody>
    <tr>
      <td class="head">
        ������
      </td>
      <td class="even">
        <?php echo smarty_function_html_options(array('name' => 'gid','options' => $this->_tpl_vars['groups'],'selected' => $this->_tpl_vars['group_permission_gid']), $this);?>

      </td>
    </tr>
    <tr>
      <td class="head">
        ������
      </td>
      <td class="even">
        <input type="text" name='pattern' value='<?php echo $this->_tpl_vars['group_permission_pattern']; ?>
'  style="width: 98%;">
      </td>
    </tr>
    <tr>
      <td class="head">
        ������� �������
      </td>
      <td class="even">
        <?php echo smarty_function_html_options(array('name' => 'level','options' => $this->_tpl_vars['levels'],'selected' => $this->_tpl_vars['group_permission_level']), $this);?>

      </td>
    </tr>
    <tr>
      <td class="head">
        ��������
      </td>
      <td class="even">
        <textarea name='description' style="width: 98%;"><?php echo $this->_tpl_vars['group_permission_description']; ?>
</textarea>
      </td>
    </tr>
    </tbody>  
  </table>
  <input type="submit" name='submit' value="Save">
</form>