<?php /* Smarty version 2.6.20, created on 2013-11-01 11:26:03
         compiled from D:/www/callisto/www/modules/permissions/views/default/permissions_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'D:/www/callisto/www/modules/permissions/views/default/permissions_list.tpl', 24, false),)), $this); ?>
<h2><?php echo $this->_config[0]['vars']['permissions_header']; ?>
</h2>
<table border='1' width='100%' cellspacing=0 cellpadding=4>
  <tr>
    <th>
      <?php echo $this->_config[0]['vars']['permissions_groups_title']; ?>

    </th>
    <th>
      <?php echo $this->_config[0]['vars']['permissions_element']; ?>

    </th>
    <th>
      <?php echo $this->_config[0]['vars']['permissions_object']; ?>

    </th>
    <th>
      <?php echo $this->_config[0]['vars']['permissions_access_type']; ?>

    </th>
    <th>
      <?php echo $this->_config[0]['vars']['permissions_order']; ?>

    </th>
    <th>
     <?php echo $this->_config[0]['vars']['permissions_actions']; ?>

    </th>
   </tr>
  <?php $_from = $this->_tpl_vars['group_permission']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['permission_'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['permission_']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['permission']):
        $this->_foreach['permission_']['iteration']++;
?>
    <?php echo smarty_function_cycle(array('name' => 'permsls','values' => "even,odd",'assign' => 'class','print' => false), $this);?>

    <tr class='<?php echo $this->_tpl_vars['class']; ?>
'>
      <td>
        <?php echo $this->_tpl_vars['group'][$this->_tpl_vars['permission']['group_permission_gid']]; ?>

      </td>
      <td>
        <?php echo $this->_config[0]['vars']['permissions_element']; ?>

      </td>
      <td>
        <?php echo $this->_tpl_vars['permission']['group_permission_pattern']; ?>

      </td>
      <td>
        <?php echo $this->_tpl_vars['levels'][$this->_tpl_vars['permission']['group_permission_level']]; ?>

      </td>
      <td style="text-align: center;">
          <?php if (! ($this->_foreach['permission_']['iteration'] <= 1)): ?>
            <a href="/menu/weight_up/<?php echo $this->_tpl_vars['permission']['group_permission_weight']; ?>
"><img border="0" src="/public/images/system/up.gif"></a>
          <?php endif; ?>
          <?php if (! ($this->_foreach['permission_']['iteration'] <= 1) && ! ($this->_foreach['permission_']['iteration'] == $this->_foreach['permission_']['total'])): ?>
            &nbsp;
          <?php endif; ?>
          <?php if (! ($this->_foreach['permission_']['iteration'] == $this->_foreach['permission_']['total'])): ?>
            <a href="/menu/weight_down/<?php echo $this->_tpl_vars['permission']['group_permission_weight']; ?>
"><img border="0" src="/public/images/system/down.gif"></a>
          <?php endif; ?>
      </td>
      <td>
        <a href='/permissions/manage/<?php echo $this->_tpl_vars['permission']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
"><img alt="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
" src="/public/images/system/edit.gif"></a>
        <a href='/permissions/delete/<?php echo $this->_tpl_vars['permission']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" onclick="return confirm('<?php echo $this->_config[0]['vars']['sys_confirm_delete']; ?>
');"><img alt="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" src="/public/images/system/del.gif"></a>
      </td>
    </tr>
   <?php endforeach; endif; unset($_from); ?>
</table>
<div style="text-align: center;">
  [ <a href='/permissions/manage'>��������</a> ]
</div>