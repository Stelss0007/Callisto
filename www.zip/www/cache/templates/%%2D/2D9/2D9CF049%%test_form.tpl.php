<?php /* Smarty version 2.6.20, created on 2013-11-06 13:46:10
         compiled from D:/www/callisto/www/modules/test_task/views/default/test_form.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'appJsLoad', 'D:/www/callisto/www/modules/test_task/views/default/test_form.tpl', 1, false),array('function', 'array', 'D:/www/callisto/www/modules/test_task/views/default/test_form.tpl', 2, false),array('function', 'array_append', 'D:/www/callisto/www/modules/test_task/views/default/test_form.tpl', 3, false),array('function', 'html_options', 'D:/www/callisto/www/modules/test_task/views/default/test_form.tpl', 21, false),array('modifier', 'trim', 'D:/www/callisto/www/modules/test_task/views/default/test_form.tpl', 27, false),)), $this); ?>
<?php echo smarty_function_appJsLoad(array('modname' => 'test_task'), $this);?>

<?php echo smarty_function_array(array('name' => 'field_5_lst'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_5_lst','key' => '1','value' => '1'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_5_lst','key' => '2','value' => '2'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_5_lst','key' => '3','value' => '3'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_5_lst','key' => '4','value' => '4'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_5_lst','key' => '5','value' => '5'), $this);?>


<?php echo smarty_function_array(array('name' => 'field_6_lst'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_6_lst','key' => '1','value' => '1'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'field_6_lst','key' => '2','value' => '2'), $this);?>


<form action='/test_task/save_data' id="test_form">
  <input type="hidden" id="element_id" value="<?php echo $this->_tpl_vars['id']; ?>
">
  <input type="hidden" id="update_time" value="<?php echo $this->_tpl_vars['update_time']; ?>
">
  <table>
    <tr>
      <td>Select 1</td>
      <td>
        <select name='field_5' id='field_5'>
         <?php echo smarty_function_html_options(array('options' => $this->_tpl_vars['field_5_lst'],'selected' => $this->_tpl_vars['field_5']), $this);?>

        </select>
      </td>
    </tr>
    <tr>
      <td>Field 1</td>
      <td><input type="text" name="field_1" id="field_1" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['field_1'])) ? $this->_run_mod_handler('trim', true, $_tmp) : trim($_tmp)); ?>
" size="80"></td>
    </tr>
    <tr>
      <td>Field 2</td>
      <td><input type="text" name="field_2" id="field_2" value="<?php echo $this->_tpl_vars['field_2']; ?>
" size="80"></td>
    </tr>
    <tr>
      <td>Field 3</td>
      <td><input type="text" name="field_3" id="field_3" value="<?php echo $this->_tpl_vars['field_3']; ?>
" size="80"></td>
    </tr>
    <tr>
      <td>Field 4</td>
      <td><input type="text" name="field_4" id="field_4" value="<?php echo $this->_tpl_vars['field_4']; ?>
" size="80"></td>
    </tr>
   
  </table>
</form>