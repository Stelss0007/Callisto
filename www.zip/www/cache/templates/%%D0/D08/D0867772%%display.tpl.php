<?php /* Smarty version 2.6.20, created on 2013-11-04 11:39:15
         compiled from D:/www/callisto/www/blocks/menu_block/themes/default/display.tpl */ ?>
<?php echo '<ul>'; ?><?php $_from = $this->_tpl_vars['menu_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['menu']):
?><?php echo '<li><a href=\''; ?><?php echo $this->_tpl_vars['menu']['menu_content']; ?><?php echo '\'>'; ?><?php echo $this->_tpl_vars['menu']['menu_title']; ?><?php echo '</a></li>'; ?><?php endforeach; endif; unset($_from); ?><?php echo '</ul>'; ?>