<?php /* Smarty version 2.6.20, created on 2013-10-21 17:33:24
         compiled from D:/www/callisto/www/modules/groups/views/default/manage.tpl */ ?>
<form action="" method="post">
  <input type="hidden" name='id' value="<?php echo $this->_tpl_vars['id']; ?>
">
  <table class="outer" width='100%' style="width: 100%;" cellspacing="1" cellpadding="4">
    <colgroup>
      <col width="25%">
      <col width="75%">
    </colgroup>
    <thead>
      <tr>
        <th colspan="2">
          <?php echo $this->_config[0]['vars']['groups_edit']; ?>

        </th>
      </tr>
    </thead>
    <tfoot>
      <td colspan="2">
        <input type="submit" name='submit' value="<?php echo $this->_config[0]['vars']['groups_save']; ?>
">
      </td>
    </tfoot>
    <tbody>
      <tr>
        <td class='head'>
          <?php echo $this->_config[0]['vars']['groups_title']; ?>

        </td>
        <td  class='even'>
          <input type="text" name='group_displayname' value='<?php echo $this->_tpl_vars['group_displayname']; ?>
' style="width: 98%;">
        </td>
      </tr>

      <tr>
        <td class='head'>
          <?php echo $this->_config[0]['vars']['groups_description']; ?>

        </td>
        <td  class='even'>
          <textarea name='group_description' style="width: 98%;"><?php echo $this->_tpl_vars['group_description']; ?>
</textarea>
        </td>
      </tr>
    </tbody>
  </table>
    
</form>