<?php /* Smarty version 2.6.20, created on 2013-10-21 16:14:36
         compiled from D:/www/callisto/www/modules/groups/themes/default/groups_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'D:/www/callisto/www/modules/groups/themes/default/groups_list.tpl', 20, false),)), $this); ?>
<h2>����� �������������</h2>
<table border='1' width='100%' cellspacing=0 cellpadding=4>
  <colgroup>
    <col width='*'>
    <col width='*'>
    <col width='70'>
  </colgroup>
  <tr>
    <th>
      ��� ������
    </th>
    <th>
      ��������
    </th>
    <th>
      ��������
    </th>
   </tr>
   <?php $_from = $this->_tpl_vars['groups_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['group']):
?>
    <?php echo smarty_function_cycle(array('name' => 'groups','values' => "even,odd",'assign' => 'class','print' => false), $this);?>

    <tr class='<?php echo $this->_tpl_vars['class']; ?>
'>
      <td>
        <?php echo $this->_tpl_vars['group']['group_displayname']; ?>

      </td>
     
      <td>
        <?php echo $this->_tpl_vars['group']['group_description']; ?>

      </td>
      
      <td style="text-align: center;">
        <a href='/groups/manage/<?php echo $this->_tpl_vars['group']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
"><img alt="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
" src="/public/images/system/edit.gif"></a>
        <a href='/groups/delete/<?php echo $this->_tpl_vars['group']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" onclick="return confirm('<?php echo $this->_config[0]['vars']['sys_confirm_delete']; ?>
');"><img alt="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" src="/public/images/system/del.gif"></a>
      </td>
    </tr>
   <?php endforeach; endif; unset($_from); ?>
</table>
<div style="text-align: center;">
  [ <a href='/groups/manage'>��������</a> ]
</div>