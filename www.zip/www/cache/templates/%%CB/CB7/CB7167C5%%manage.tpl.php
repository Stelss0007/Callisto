<?php /* Smarty version 2.6.20, created on 2013-11-04 17:24:12
         compiled from D:/www/callisto/www/modules/users/views/default/manage.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'array', 'D:/www/callisto/www/modules/users/views/default/manage.tpl', 1, false),array('function', 'array_append', 'D:/www/callisto/www/modules/users/views/default/manage.tpl', 2, false),array('function', 'html_options', 'D:/www/callisto/www/modules/users/views/default/manage.tpl', 39, false),array('function', 'html_radios', 'D:/www/callisto/www/modules/users/views/default/manage.tpl', 64, false),)), $this); ?>
<?php echo smarty_function_array(array('name' => 'yes_no'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'yes_no','key' => '1','value' => "��"), $this);?>

<?php echo smarty_function_array_append(array('name' => 'yes_no','key' => '0','value' => "���"), $this);?>


<form action="" method="post">
  <input type="hidden" name='id' value="<?php echo $this->_tpl_vars['id']; ?>
">
  <table width='100%' class="outer" cellSpacing="1" cellPadding="4" >
  <col width='220' >
  <col width='*'>
  <thead>
    <tr>
      <th colspan="2"><?php echo $this->_config[0]['vars']['user_edit']; ?>
</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_login']; ?>

      </td>
      <td  class="even">
        <input type="text" name='login' size='40' value='<?php echo $this->_tpl_vars['login']; ?>
'>
      </td>
    </tr>

    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_pass']; ?>

      </td>
      <td class="even">
        <input type="password" name='pass' size='40' value=''>
      </td>
    </tr>

    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_group']; ?>

      </td>
      <td class="even">
        <?php echo smarty_function_html_options(array('name' => 'gid','options' => $this->_tpl_vars['groups'],'selected' => $this->_tpl_vars['gid']), $this);?>

      </td>
    </tr>

    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_email']; ?>

      </td>
      <td class="even">
        <input type="text" name='mail' size='40' value='<?php echo $this->_tpl_vars['mail']; ?>
'>
      </td>
    </tr>
    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_fio']; ?>

      </td>
      <td class="even">
        <input type="text" name='displayname' size='40' value='<?php echo $this->_tpl_vars['displayname']; ?>
'>
      </td>
    </tr>
    <tr>
      <td class="head">
        <?php echo $this->_config[0]['vars']['user_active']; ?>

      </td>
      <td class="even">
        <?php echo smarty_function_html_radios(array('name' => 'active','options' => $this->_tpl_vars['yes_no'],'checked' => $this->_tpl_vars['active'],'separator' => ' '), $this);?>

      </td>
    </tr>
  </tbody>
</table>
    <center>
      <input type="submit" name='submit' value="<?php echo $this->_config[0]['vars']['sys_save']; ?>
">
    </center>
</form>