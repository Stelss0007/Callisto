<?php /* Smarty version 2.6.20, created on 2013-10-21 15:45:57
         compiled from D:/www/callisto/www/modules/users/themes/default/manage.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'array', 'D:/www/callisto/www/modules/users/themes/default/manage.tpl', 1, false),array('function', 'array_append', 'D:/www/callisto/www/modules/users/themes/default/manage.tpl', 2, false),array('function', 'html_options', 'D:/www/callisto/www/modules/users/themes/default/manage.tpl', 34, false),array('function', 'html_radios', 'D:/www/callisto/www/modules/users/themes/default/manage.tpl', 59, false),)), $this); ?>
<?php echo smarty_function_array(array('name' => 'yes_no'), $this);?>

<?php echo smarty_function_array_append(array('name' => 'yes_no','key' => '1','value' => "��"), $this);?>

<?php echo smarty_function_array_append(array('name' => 'yes_no','key' => '0','value' => "���"), $this);?>


<h2>�������������� ������������</h2>
<form action="" method="post">
<table width='100%'>
  <input type="hidden" name='id' value="<?php echo $this->_tpl_vars['id']; ?>
">
  <col width='220' >
  <col width='*'>
  <tr>
    <td>
      �����
    </td>
    <td>
      <input type="text" name='login' size='40' value='<?php echo $this->_tpl_vars['login']; ?>
'>
    </td>
  </tr>
  
  <tr>
    <td>
      ������
    </td>
    <td>
      <input type="password" name='pass' size='40' value=''>
    </td>
  </tr>

  <tr>
    <td>
      ������
    </td>
    <td>
      <?php echo smarty_function_html_options(array('name' => 'gid','options' => $this->_tpl_vars['groups'],'selected' => $this->_tpl_vars['gid']), $this);?>

    </td>
  </tr>
  
  <tr>
    <td>
      Email
    </td>
    <td>
      <input type="text" name='mail' size='40' value='<?php echo $this->_tpl_vars['mail']; ?>
'>
    </td>
  </tr>
  <tr>
    <td>
      ���(�.�.�)
    </td>
    <td>
      <input type="text" name='displayname' size='40' value='<?php echo $this->_tpl_vars['displayname']; ?>
'>
    </td>
  </tr>
  <tr>
    <td>
      �����������
    </td>
    <td>
      <?php echo smarty_function_html_radios(array('name' => 'active','options' => $this->_tpl_vars['yes_no'],'checked' => $this->_tpl_vars['active'],'separator' => ' '), $this);?>

    </td>
  </tr>
</table>
    <center>
      <input type="submit" name='submit' value="Save">
    </center>
</form>