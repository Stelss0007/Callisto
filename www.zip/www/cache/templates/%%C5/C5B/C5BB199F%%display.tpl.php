<?php /* Smarty version 2.6.20, created on 2013-10-21 11:08:54
         compiled from D:/www/callisto/www/themes/green/blocks/anekdot_block/display.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'wordwrap', 'D:/www/callisto/www/themes/green/blocks/anekdot_block/display.tpl', 2, false),)), $this); ?>
<?php echo ''; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['anekdot'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp, 25, '<br>') : smarty_modifier_wordwrap($_tmp, 25, '<br>')); ?><?php echo ''; ?>

