<?php /* Smarty version 2.6.20, created on 2013-11-04 11:06:04
         compiled from D:/www/callisto/www/modules/theme/views/default/theme_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'bbeditor', 'D:/www/callisto/www/modules/theme/views/default/theme_list.tpl', 3, false),array('function', 'texteditor', 'D:/www/callisto/www/modules/theme/views/default/theme_list.tpl', 4, false),)), $this); ?>

THEME LIST12
<?php echo smarty_function_bbeditor(array(), $this);?>

<?php echo smarty_function_texteditor(array(), $this);?>