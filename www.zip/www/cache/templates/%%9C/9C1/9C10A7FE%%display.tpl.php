<?php /* Smarty version 2.6.20, created on 2013-10-21 10:45:10
         compiled from D:/www/callisto/www/themes/green/blocks/menu_block/display.tpl */ ?>
<?php echo ''; ?><?php $_from = $this->_tpl_vars['menu_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['menu']):
?><?php echo '<a class="usermnuline" href="'; ?><?php echo $this->_tpl_vars['menu']['menu_content']; ?><?php echo '">'; ?><?php echo $this->_tpl_vars['menu']['menu_title']; ?><?php echo '</a>'; ?><?php endforeach; endif; unset($_from); ?><?php echo ''; ?>