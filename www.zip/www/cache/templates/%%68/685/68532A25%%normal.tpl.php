<?php /* Smarty version 2.6.20, created on 2013-10-18 16:12:48
         compiled from themes/green/messages/normal.tpl */ ?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<meta http-equiv="Refresh" content="<?php echo $this->_tpl_vars['time']; ?>
; url=<?php echo $this->_tpl_vars['url']; ?>
" />
<style type="text/css">
    body {background-color : #99BA77; font-size: 12px; font-family: Trebuchet MS,Verdana, Arial, Helvetica, sans-serif; margin: 0px;}
    .redirect {width: 70%; margin: 110px; text-align: center; padding: 15px; border: #e0e0e0 1px solid; color: #666666; background-color: #f6f6f6;}
    .redirect a:link {color: #666666; text-decoration: none; font-weight: bold;}
    .redirect a:visited {color: #666666; text-decoration: none; font-weight: bold;}
    .redirect a:hover {color: #999999; text-decoration: underline; font-weight: bold;}
</style>

</head>
<body>
<div align="center">
<div class="redirect">
  <span style="font-size: 16px; font-weight: bold;"><?php echo $this->_tpl_vars['message']; ?>
</span>
  <hr style="height: 3px; border: 2px #99BA77 solid; width: 95%;" />
  <p>���� �������� ������������� �� ��������������, ���������� ������� <a href='<?php echo $this->_tpl_vars['url']; ?>
'>����</a></p>
</div>
</div>
</body>
</html>