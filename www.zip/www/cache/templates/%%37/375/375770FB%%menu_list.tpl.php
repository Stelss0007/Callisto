<?php /* Smarty version 2.6.20, created on 2013-10-21 12:02:44
         compiled from D:/www/callisto/www/modules/menu/themes/default/menu_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'D:/www/callisto/www/modules/menu/themes/default/menu_list.tpl', 27, false),)), $this); ?>
<h2><?php echo $this->_config[0]['vars']['menu_header']; ?>
</h2>
<table border='1' width='100%' cellspacing=0 cellpadding=4>
  <colgroup>
    <col width='340'>
    <col width='*'>
    <col width='40'>
    <col width='80'>
  </colgroup>
  <thead>
    <tr>
      <th>
        <?php echo $this->_config[0]['vars']['menu_title']; ?>

      </th>
      <th>
        <?php echo $this->_config[0]['vars']['menu_url']; ?>

      </th>
      <th>
        <?php echo $this->_config[0]['vars']['menu_order']; ?>

      </th>
      <th>
        <?php echo $this->_config[0]['vars']['menu_actions']; ?>

      </th>
   </tr>
  </thead>
  <tbody>
   <?php $_from = $this->_tpl_vars['menus']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['menu_'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['menu_']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['menu']):
        $this->_foreach['menu_']['iteration']++;
?>
    <?php echo smarty_function_cycle(array('name' => 'menu','values' => "even,odd",'assign' => 'class','print' => false), $this);?>

    <tr class='<?php echo $this->_tpl_vars['class']; ?>
'>
      <td>
        <a href="/menu/menu_list/<?php echo $this->_tpl_vars['menu']['id']; ?>
"><?php echo $this->_tpl_vars['menu']['menu_title']; ?>
<?php if ($this->_tpl_vars['menu']['menu_subitem_counter'] > 0): ?>&nbsp;(<?php echo $this->_tpl_vars['menu']['menu_subitem_counter']; ?>
)<?php endif; ?></a>
      </td>
     
      <td>
        <a href="<?php echo $this->_tpl_vars['menu']['menu_content']; ?>
"><?php echo $this->_tpl_vars['menu']['menu_content']; ?>
</a>
      </td>
      <td style="text-align: center;">
          <?php if (! ($this->_foreach['menu_']['iteration'] <= 1)): ?>
            <a href="/menu/weight_up/<?php echo $this->_tpl_vars['menu']['menu_weight']; ?>
/<?php echo $this->_tpl_vars['menu']['menu_parent_id']; ?>
"><img border="0" src="/public/images/system/up.gif"></a>
          <?php endif; ?>
          <?php if (! ($this->_foreach['menu_']['iteration'] <= 1) && ! ($this->_foreach['menu_']['iteration'] == $this->_foreach['menu_']['total'])): ?>
            &nbsp;
          <?php endif; ?>
          <?php if (! ($this->_foreach['menu_']['iteration'] == $this->_foreach['menu_']['total'])): ?>
            <a href="/menu/weight_down/<?php echo $this->_tpl_vars['menu']['menu_weight']; ?>
/<?php echo $this->_tpl_vars['menu']['menu_parent_id']; ?>
"><img border="0" src="/public/images/system/down.gif"></a>
          <?php endif; ?>
             </td>
      <td>
        <a href='/menu/modify/<?php echo $this->_tpl_vars['menu']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
"><img alt="<?php echo $this->_config[0]['vars']['sys_edit']; ?>
" src="/public/images/system/edit.gif"></a>
        <a href='/menu/delete/<?php echo $this->_tpl_vars['menu']['id']; ?>
' title="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" onclick="return confirm('<?php echo $this->_config[0]['vars']['sys_confirm_delete']; ?>
');"><img alt="<?php echo $this->_config[0]['vars']['sys_delete']; ?>
" src="/public/images/system/del.gif"></a>
      </td>
    </tr>
   <?php endforeach; endif; unset($_from); ?>
  </tbody>
</table>
<div style="text-align: center;">
  [ <a href='/menu/create<?php if ($this->_tpl_vars['parent_id']): ?>/<?php echo $this->_tpl_vars['parent_id']; ?>
<?php endif; ?>'><?php echo $this->_config[0]['vars']['menu_add']; ?>
</a> ]
</div>