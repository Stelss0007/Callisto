<?php /* Smarty version 2.6.20, created on 2013-10-16 10:02:55
         compiled from D:/www/callisto/www/blocks/test_block/themes/default/display.tpl */ ?>
<?php echo ''; ?><?php $_from = $this->_tpl_vars['groups']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['key'] => $this->_tpl_vars['group']):
?><?php echo '<a class=\'usermnuline\' href="#">'; ?><?php echo $this->_tpl_vars['group']; ?><?php echo '</a>'; ?><?php endforeach; endif; unset($_from); ?><?php echo ''; ?>
