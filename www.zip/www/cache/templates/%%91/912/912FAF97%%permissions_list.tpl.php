<?php /* Smarty version 2.6.20, created on 2013-10-16 10:02:55
         compiled from D:/www/callisto/www/modules/permissions/themes/default/permissions_list.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'cycle', 'D:/www/callisto/www/modules/permissions/themes/default/permissions_list.tpl', 24, false),)), $this); ?>
<h2>����� ������� ����</h2>
<table border='1' width='100%' cellspacing=0 cellpadding=4>
  <tr>
    <th>
      ������
    </th>
    <th>
      �������
    </th>
    <th>
      ������
    </th>
    <th>
      ����� �������
    </th>
    <th>
      �������������
    </th>
    <th>
      ��������
    </th>
   </tr>
  <?php $_from = $this->_tpl_vars['group_permission']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['permission']):
?>
    <?php echo smarty_function_cycle(array('name' => 'permsls','values' => "even,odd",'assign' => 'class','print' => false), $this);?>

    <tr class='<?php echo $this->_tpl_vars['class']; ?>
'>
      <td>
        <?php echo $this->_tpl_vars['group'][$this->_tpl_vars['permission']['gid']]; ?>

      </td>
      <td>
        �������
      </td>
      <td>
        <?php echo $this->_tpl_vars['permission']['pattern']; ?>

      </td>
      <td>
        <?php echo $this->_tpl_vars['levels'][$this->_tpl_vars['permission']['level']]; ?>

      </td>
      <td>
        <a href='/permissions/permission_weight_up/<?php echo $this->_tpl_vars['permission']['weight']; ?>
'>UP</a>
        &nbsp;
        <a href='/permissions/permission_weight_down/<?php echo $this->_tpl_vars['permission']['weight']; ?>
'>DOWN</a>
      </td>
      <td>
        <a href='/permissions/manage/<?php echo $this->_tpl_vars['permission']['id']; ?>
'>Edit</a>
        <a href='/permissions/delete/<?php echo $this->_tpl_vars['permission']['id']; ?>
' onclick="return confirm('������� �������?')">Delete</a>
      </td>
    </tr>
   <?php endforeach; endif; unset($_from); ?>
</table>
<div style="text-align: center;">
  [ <a href='/permissions/manage'>��������</a> ]
</div>