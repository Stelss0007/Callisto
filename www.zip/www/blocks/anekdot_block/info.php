<?php
$info['block_name'] = 'anekdot_block';
$info['block_type'] = 'block';
$info['block_displayname'] = '������� ���';
$info['block_version'] = '0.31';
$info['block_description'] = '������� ��� � anekdotov.net';
$info['block_credits'] = '';
$info['block_changelog'] = '';
$info['block_license'] = '';
$info['block_official'] = 1;
$info['block_author'] = '';
$info['block_contact'] = '';
$info['block_refresh'] = false;
$info['block_language'] = '';
?>
