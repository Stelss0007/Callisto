<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class Test extends Model
  {
  function sum($a = 1, $b = 2)
    {
    return $a + $b;
    }
  }
?>
