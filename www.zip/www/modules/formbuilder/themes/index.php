<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of index
 *
 * @author Your Name <your.name at your.org>
 */
class Index extends Controller
  {
  //put your code here
  }

?>
