<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of class
 *
 * @author Your Name <your.name at your.org>
 */
class Formbuilder extends Model{
//put your code here
}
?>
