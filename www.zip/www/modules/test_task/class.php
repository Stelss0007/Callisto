<?php
class Test_task extends Model
  {
  var $table = 'test_task';
  }
?>