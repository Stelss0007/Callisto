<?php
function smarty_modifier_round($string, $precision=3)
  {
  return round ($string, $precision);
  }

?>
